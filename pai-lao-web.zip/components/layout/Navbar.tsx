"use client";
import Link from "next/link";

export default function Navbar() {
  return (
    <nav style={{
      position: "sticky", top: 0, zIndex: 1000, 
      background: "#ffffff", height: "80px", 
      display: "flex", alignItems: "center", justifyContent: "center",
      borderBottom: "1px solid #eeeeee",
      boxShadow: "0 2px 10px rgba(0,0,0,0.05)"
    }}>
      <div style={{
        width: "100%", maxWidth: "1200px", padding: "0 20px",
        display: "flex", justifyContent: "space-between", alignItems: "center"
      }}>
        
        {/* 1. โลโก้ */}
        <Link href="/" style={{ display: "flex", alignItems: "center", gap: "10px", textDecoration: "none" }}>
          <div style={{ fontSize: "30px" }}>💬</div>
          <div style={{ display: "flex", flexDirection: "column" }}>
            <h1 style={{ margin: 0, fontSize: "24px", fontWeight: "900", lineHeight: 1 }}>
              <span style={{ color: "#3b82f6" }}>ไป</span><span style={{ color: "#10b981" }}>เล่า</span>
            </h1>
            <p style={{ margin: 0, fontSize: "9px", color: "#999", fontWeight: "bold" }}>PAI-LAO EXPERIENCE</p>
          </div>
        </Link>

        {/* 2. แถบค้นหา */}
        <div style={{
          display: "flex", alignItems: "center", background: "#f3f4f6",
          borderRadius: "50px", padding: "4px 15px", flex: "0 1 450px", border: "1px solid #e5e7eb"
        }}>
          <select style={{ background: "none", border: "none", padding: "8px", outline: "none", fontSize: "14px", borderRight: "1px solid #ddd", cursor: "pointer" }}>
            <option>ทริป</option>
            <option>ที่เที่ยว</option>
          </select>
          <input type="text" placeholder="ค้นหาทริปหรือสถานที่..." style={{ background: "none", border: "none", padding: "8px 15px", width: "100%", outline: "none", fontSize: "14px" }} />
          <span style={{ cursor: "pointer" }}>🔍</span>
        </div>

        {/* 3. ปุ่มกด (เน้นแก้ที่นี่: ตัดขีดเส้นใต้ และทำเป็นก้อนปุ่ม) */}
        <div style={{ display: "flex", alignItems: "center", gap: "20px" }}>
          
          <Link href="/login" style={{
            textDecoration: "none", // บังคับลบขีดเส้นใต้
            color: "#3b82f6",      // สีฟ้าตามสั่ง
            fontWeight: "700",
            fontSize: "14px",
            textTransform: "uppercase"
          }}>
            เข้าสู่ระบบ
          </Link>

          <Link href="/signup" style={{
            textDecoration: "none",      // บังคับลบขีดเส้นใต้
            background: "#10b981",       // สีเขียวตามสั่ง
            color: "#ffffff",            // ตัวอักษรขาวเพื่อให้ตัดกับพื้นเขียว
            padding: "12px 25px",
            borderRadius: "12px",        // ขอบมนตามรูปตัวอย่าง
            fontWeight: "700",
            fontSize: "14px",
            textTransform: "uppercase",
            boxShadow: "0 4px 6px rgba(16, 185, 129, 0.2)",
            display: "inline-block"
          }}>
            สมัครสมาชิก
          </Link>

        </div>
      </div>
    </nav>
  );
}
