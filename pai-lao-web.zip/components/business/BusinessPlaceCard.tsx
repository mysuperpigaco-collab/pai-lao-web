"use client";

import Link from "next/link";

type Props = {
  slug: string;
  title: string;
  location: string;
  image: string;
  category?: string;
  rating?: string;
  status?: "active" | "pending" | "inactive";
  views?: number;
  checkins?: number;
};

const STATUS_MAP = {
  active:   { text: "เผยแพร่ · Active",   bg: "#dcfce7", color: "#15803d", dot: "#22c55e" },
  pending:  { text: "รอตรวจสอบ · Pending", bg: "#fef3c7", color: "#92400e", dot: "#f59e0b" },
  inactive: { text: "ปิดใช้ · Inactive",  bg: "#f1f5f9", color: "#475569", dot: "#94a3b8" },
};

export default function BusinessPlaceCard({
  slug,
  title,
  location,
  image,
  category = "สถานที่ท่องเที่ยว",
  rating,
  status = "active",
  views = 0,
  checkins = 0,
}: Props) {
  const st = STATUS_MAP[status];

  /* ─── Shared inline style objects ─── */
  const card: React.CSSProperties = {
    background: "#ffffff",
    borderRadius: "28px",
    overflow: "hidden",
    border: "1px solid #f1f5f9",
    boxShadow: "0 4px 20px rgba(15,23,42,0.05)",
    display: "flex",
    flexDirection: "column",
    transition: "transform 0.3s, box-shadow 0.3s",
  };

  /* ✅ ปุ่ม "ดูหน้าเพจ" — inline ทั้งหมด */
  const btnView: React.CSSProperties = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "6px",
    flex: 1,
    padding: "11px 10px",
    borderRadius: "12px",
    background: "#eff6ff",
    color: "#2563eb",
    textDecoration: "none",
    fontSize: "13px",
    fontWeight: 800,
    border: "none",
    cursor: "pointer",
    whiteSpace: "nowrap" as const,
  };

  /* ✅ ปุ่ม "แก้ไข" — gradient inline ทั้งหมด */
  const btnEdit: React.CSSProperties = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "6px",
    flex: 1,
    padding: "11px 10px",
    borderRadius: "12px",
    background: "linear-gradient(135deg, #4facfe 0%, #43e97b 100%)",
    color: "#ffffff",
    textDecoration: "none",
    fontSize: "13px",
    fontWeight: 800,
    border: "none",
    cursor: "pointer",
    whiteSpace: "nowrap" as const,
    boxShadow: "0 4px 12px rgba(79,172,254,0.22)",
  };

  const btnDel: React.CSSProperties = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    width: "44px",
    flexShrink: 0,
    padding: "11px 0",
    borderRadius: "12px",
    background: "#fff5f5",
    color: "#dc2626",
    fontSize: "16px",
    border: "1px solid #fecaca",
    cursor: "pointer",
  };

  return (
    <div style={card}>

      {/* ── Image ── */}
      <div style={{ position: "relative", height: "220px", overflow: "hidden", flexShrink: 0 }}>
        <img
          src={`${image}?q=80&w=800`}
          alt={title}
          style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
          loading="lazy"
        />
        {/* Overlay gradient */}
        <div style={{
          position: "absolute", inset: 0,
          background: "linear-gradient(to top, rgba(15,23,42,0.65), transparent 55%)",
        }} />

        {/* Category pill ซ้ายล่าง */}
        <span style={{
          position: "absolute", bottom: "14px", left: "14px",
          background: "rgba(255,255,255,0.18)",
          backdropFilter: "blur(8px)",
          color: "#ffffff",
          padding: "5px 12px",
          borderRadius: "999px",
          fontSize: "11px",
          fontWeight: 800,
          border: "1px solid rgba(255,255,255,0.25)",
        }}>
          {category}
        </span>

        {/* Status badge ขวาบน */}
        <span style={{
          position: "absolute", top: "14px", right: "14px",
          display: "inline-flex", alignItems: "center", gap: "5px",
          padding: "5px 12px", borderRadius: "999px",
          background: st.bg, color: st.color,
          fontSize: "11px", fontWeight: 800,
          boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
        }}>
          <span style={{ width: "7px", height: "7px", borderRadius: "50%", background: st.dot, flexShrink: 0 }} />
          {st.text}
        </span>

        {/* Rating badge ถ้ามี */}
        {rating && (
          <span style={{
            position: "absolute", top: "14px", left: "14px",
            background: "rgba(255,255,255,0.92)",
            backdropFilter: "blur(8px)",
            color: "#f59e0b",
            padding: "5px 10px",
            borderRadius: "999px",
            fontSize: "12px",
            fontWeight: 800,
          }}>
            ⭐ {rating}
          </span>
        )}
      </div>

      {/* ── Body ── */}
      <div style={{ padding: "20px 22px 14px", flex: 1 }}>
        <h3 style={{ fontSize: "19px", fontWeight: 900, color: "#0f172a", margin: "0 0 5px", lineHeight: 1.3 }}>
          {title}
        </h3>
        <p style={{ fontSize: "13px", color: "#64748b", margin: "0 0 16px" }}>
          📍 {location}
        </p>

        {/* Stats */}
        <div style={{
          display: "flex", alignItems: "center", gap: "16px",
          padding: "12px 14px",
          background: "#f8fafc", borderRadius: "12px",
        }}>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "2px", flex: 1 }}>
            <strong style={{ fontSize: "17px", fontWeight: 900, color: "#0f172a" }}>{views.toLocaleString()}</strong>
            <span style={{ fontSize: "11px", color: "#64748b", fontWeight: 600 }}>Views</span>
          </div>
          <div style={{ width: "1px", height: "28px", background: "#e2e8f0" }} />
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "2px", flex: 1 }}>
            <strong style={{ fontSize: "17px", fontWeight: 900, color: "#0f172a" }}>{checkins.toLocaleString()}</strong>
            <span style={{ fontSize: "11px", color: "#64748b", fontWeight: 600 }}>Check-ins</span>
          </div>
        </div>
      </div>

      {/* ── Actions — pure inline style ── */}
      <div style={{ display: "flex", gap: "8px", padding: "12px 22px 22px" }}>

        {/* ✅ ดูหน้าเพจ */}
        <Link href={`/place/${slug}`} style={btnView}>
          👁 ดูหน้าเพจ
        </Link>

        {/* ✅ แก้ไข */}
        <Link href={`/business/places/${slug}/edit`} style={btnEdit}>
          ✏️ แก้ไข
        </Link>

        {/* ลบ */}
        <button style={btnDel} title="ลบสถานที่">
          🗑
        </button>

      </div>
    </div>
  );
}
