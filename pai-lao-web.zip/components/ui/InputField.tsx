/*
 * components/ui/InputField.tsx
 * ✅ ใช้ class จาก form-card.css (ui-field, ui-input)
 *    ไม่ใช้ form-group / form-control จาก globals อีกต่อไป
 */

import "@/components/ui/form-card.css";

type Props = {
  label: string;
  labelEn?: string;
  required?: boolean;
  type?: string;
  placeholder?: string;
  value?: string;
  defaultValue?: string;
  name?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  disabled?: boolean;
  readOnly?: boolean;
  hint?: string;
};

export default function InputField({
  label,
  labelEn,
  required = false,
  type = "text",
  placeholder,
  value,
  defaultValue,
  name,
  onChange,
  disabled = false,
  readOnly = false,
  hint,
}: Props) {
  return (
    <div className="ui-field">
      <label>
        {label}
        {labelEn && <span className="en">{labelEn}</span>}
        {required && <span className="req">*</span>}
      </label>

      <input
        type={type}
        name={name}
        className="ui-input"
        placeholder={placeholder}
        value={value}
        defaultValue={defaultValue}
        onChange={onChange}
        disabled={disabled}
        readOnly={readOnly}
      />

      {hint && (
        <span style={{ fontSize: "12px", color: "var(--pl-text-muted)", marginTop: "5px" }}>
          {hint}
        </span>
      )}
    </div>
  );
}
