"use client";

import { useState } from "react";
import Link from "next/link";
import ProfileHeader from "@/components/dashboard/ProfileHeader";
import StoryCard from "@/components/dashboard/StoryCard";

/* ── Mock data ── */
const MY_STORIES = [
  { id: 1, title: "หนีร้อนไปพึ่งเย็นที่ดอยอินทนนท์", status: "published" as const, date: "12 พ.ค. 2024", img: "https://picsum.photos/seed/story21/600/400" },
  { id: 2, title: "คาเฟ่เปิดใหม่ย่านอารีย์ ห้ามพลาด!", status: "wait"      as const, date: "5 พ.ค. 2024",  img: "https://picsum.photos/seed/story22/600/400" },
  { id: 3, title: "เดินตลาดน้ำอัมพวา หาของกินเพลิน", status: "draft"     as const, date: "28 เม.ย. 2024", img: "https://picsum.photos/seed/story23/600/400" },
];

const SAVED_STORIES = [
  { id: 4, title: "ทริปเกาะสมุย 3 วัน 2 คืน งบไม่เกิน 5,000", status: "published" as const, date: "1 พ.ค. 2024", img: "https://picsum.photos/seed/story24/600/400" },
];

const NOTIFICATIONS = [
  { id: 1, icon: "✅", text: "เรื่องเล่า 'ดอยอินทนนท์' ได้รับการอนุมัติแล้ว",  time: "2 ชม. ที่แล้ว" },
  { id: 2, icon: "❤️", text: "สมหญิง และอีก 5 คน ถูกใจเรื่องเล่าของคุณ",       time: "5 ชม. ที่แล้ว" },
  { id: 3, icon: "💬", text: "มีความคิดเห็นใหม่ในเรื่อง 'ตลาดน้ำอัมพวา'",       time: "เมื่อวาน" },
];

/* ── Inline style for Write button (ป้องกัน Link reset) ── */
const WRITE_BTN: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  gap: "12px",
  padding: "10px 20px 10px 10px",
  borderRadius: "14px",
  /* gradient ฟ้า→เขียว ทีมเดียวกับโปรเจกต์ */
  background: "linear-gradient(135deg, #4facfe 0%, #43e97b 100%)",
  color: "#ffffff",
  textDecoration: "none",
  border: "none",
  cursor: "pointer",
  boxShadow: "0 6px 18px rgba(79,172,254,0.30)",
  fontFamily: "inherit",
};

const WRITE_ICON: React.CSSProperties = {
  width: "36px",
  height: "36px",
  borderRadius: "10px",
  background: "rgba(255,255,255,0.22)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  flexShrink: 0,
};

const WRITE_TEXT_WRAP: React.CSSProperties = {
  display: "flex",
  flexDirection: "column",
  gap: "3px",
  textAlign: "left",
  lineHeight: 1,
};

const WRITE_STRONG: React.CSSProperties = {
  fontSize: "14px",
  fontWeight: 900,
  color: "#ffffff",
  display: "block",
};

const WRITE_SMALL: React.CSSProperties = {
  fontSize: "10px",
  fontWeight: 400,
  color: "rgba(255,255,255,0.82)",
  display: "block",
};

const IconWrite = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
    <path d="M12 5H7a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-5"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M18.375 2.625a1.875 1.875 0 1 1 2.65 2.65L12 14.25l-4 1 1-4 9.375-8.625Z"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

/* ── Stat card ── */
function StatCard({ label, labelEn, value, color }: {
  label: string; labelEn: string; value: string | number; color?: string;
}) {
  return (
    <div className="stat-card">
      <strong style={{ color: color ?? "#0f172a" }}>{value}</strong>
      <span>{label}<small> {labelEn}</small></span>
      <style jsx>{`
        .stat-card {
          display: flex; flex-direction: column; align-items: center;
          gap: 4px; flex: 1; padding: 16px 12px;
          background: #f8fafc; border-radius: 16px;
        }
        strong { font-size: 24px; font-weight: 900; line-height: 1; }
        span   { font-size: 12px; color: #64748b; text-align: center; }
        small  { color: #94a3b8; font-size: 10px; }
      `}</style>
    </div>
  );
}

/* ── Interest tag ── */
function InterestTag({ label }: { label: string }) {
  return (
    <span className="itag">
      {label}
      <style jsx>{`
        .itag {
          display: inline-block; padding: 7px 14px; border-radius: 999px;
          background: #eff6ff; color: #2563eb; border: 1px solid #dbeafe;
          font-size: 12px; font-weight: 600;
        }
      `}</style>
    </span>
  );
}

/* ── Main Page ── */
export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState<"my-stories" | "saved">("my-stories");
  const stories = activeTab === "my-stories" ? MY_STORIES : SAVED_STORIES;

  return (
    <div className="dp-page">
      <div className="dp-container">

        <ProfileHeader isOwner={true} />

        <div className="dp-grid">

          {/* ── SIDEBAR ── */}
          <aside className="dp-sidebar">

            <div className="dp-card">
              <div className="noti-hdr">
                <h3>การแจ้งเตือน <small>Notifications</small></h3>
                <span className="noti-badge">{NOTIFICATIONS.length}</span>
              </div>
              <div className="noti-list">
                {NOTIFICATIONS.map((n) => (
                  <div className="noti-item" key={n.id}>
                    <span className="noti-icon">{n.icon}</span>
                    <div>
                      <p>{n.text}</p>
                      <span>{n.time}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="dp-card">
              <h3 className="sb-title">สถิติคนเล่า <small>Statistics</small></h3>
              <div className="stats-row">
                <StatCard label="เรื่องเล่า" labelEn="Stories"  value={MY_STORIES.length} color="#2563eb" />
                <StatCard label="ถูกใจ"      labelEn="Likes"     value="1.2k"               color="#22a06b" />
                <StatCard label="ติดตาม"     labelEn="Following" value={142} />
              </div>
            </div>

            <div className="dp-card">
              <h3 className="sb-title">สิ่งที่สนใจ <small>Interests</small></h3>
              <div className="int-wrap">
                {["☕ Café", "⛰️ Trekking", "📸 Photo", "🍲 Foodie", "🌊 Sea & Island"].map((t) => (
                  <InterestTag key={t} label={t} />
                ))}
              </div>
            </div>

          </aside>

          {/* ── MAIN ── */}
          <main className="dp-main">
            <div className="dp-card main-card">

              <div className="tab-bar">
                <div className="tabs">
                  {(["my-stories", "saved"] as const).map((id) => (
                    <button
                      key={id}
                      className={`tab-btn ${activeTab === id ? "active" : ""}`}
                      onClick={() => setActiveTab(id)}
                    >
                      {id === "my-stories" ? "เรื่องเล่าของฉัน · My Stories" : "บันทึกไว้ · Saved"}
                    </button>
                  ))}
                </div>

                {/* ✅ ปุ่มเขียนเรื่องใหม่ — pure inline style */}
                <Link href="/trips/create" style={WRITE_BTN}>
                  <span style={WRITE_ICON}>
                    <IconWrite />
                  </span>
                  <span style={WRITE_TEXT_WRAP}>
                    <strong style={WRITE_STRONG}>เขียนเรื่องใหม่</strong>
                    <small style={WRITE_SMALL}>แชร์ประสบการณ์การเดินทาง</small>
                  </span>
                </Link>
              </div>

              <p className="info-row">
                พบ <strong>{stories.length}</strong> รายการ
              </p>

              {stories.length > 0 ? (
                <div className="story-grid">
                  {stories.map((story) => (
                    <StoryCard key={story.id} story={story} isOwner={true} />
                  ))}
                </div>
              ) : (
                <div className="empty-state">
                  <span>📭</span>
                  <p>ยังไม่มีเรื่องเล่า · No stories yet</p>
                  <Link href="/trips/create" style={{ ...WRITE_BTN, marginTop: "16px" }}>
                    <span style={WRITE_ICON}><IconWrite /></span>
                    <span style={WRITE_TEXT_WRAP}>
                      <strong style={WRITE_STRONG}>เขียนเรื่องแรก</strong>
                      <small style={WRITE_SMALL}>Start writing</small>
                    </span>
                  </Link>
                </div>
              )}

            </div>
          </main>

        </div>
      </div>

      <style jsx>{`
        .dp-page { min-height: 100vh; background: #f8fafc; padding: 36px 0 80px; }
        .dp-container { max-width: 1280px; margin: 0 auto; padding: 0 20px; }

        .dp-grid {
          display: grid;
          grid-template-columns: 300px 1fr;
          gap: 28px; align-items: start;
        }

        .dp-card {
          background: white; border-radius: 28px; padding: 28px;
          border: 1px solid #f1f5f9;
          box-shadow: 0 2px 12px rgba(15,23,42,0.04);
          margin-bottom: 20px;
        }
        .dp-card:last-child { margin-bottom: 0; }

        .dp-sidebar { position: sticky; top: 100px; }

        .noti-hdr { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .noti-hdr h3 { font-size: 15px; font-weight: 900; color: #1e293b; margin: 0; }
        .noti-hdr small { font-size: 11px; color: #94a3b8; font-weight: 400; margin-left: 5px; }
        .noti-badge { background: #ef4444; color: white; font-size: 10px; font-weight: 800; padding: 2px 8px; border-radius: 999px; }
        .noti-list { display: flex; flex-direction: column; gap: 14px; }
        .noti-item { display: flex; gap: 12px; font-size: 13px; }
        .noti-icon { font-size: 18px; flex-shrink: 0; margin-top: 2px; }
        .noti-item p { margin: 0; color: #475569; line-height: 1.5; }
        .noti-item span { font-size: 11px; color: #94a3b8; }

        .sb-title { font-size: 15px; font-weight: 900; color: #1e293b; margin: 0 0 18px; }
        .sb-title small { font-size: 11px; color: #94a3b8; font-weight: 400; margin-left: 5px; }

        .stats-row { display: flex; gap: 10px; }
        .int-wrap { display: flex; flex-wrap: wrap; gap: 8px; }

        .main-card { padding: 32px; }

        .tab-bar {
          display: flex; justify-content: space-between;
          align-items: center; flex-wrap: wrap; gap: 12px;
          border-bottom: 2px solid #f1f5f9;
          padding-bottom: 16px; margin-bottom: 22px;
        }
        .tabs { display: flex; gap: 4px; }
        .tab-btn {
          padding: 10px 18px; border-radius: 10px; border: none;
          background: transparent; font-size: 14px; font-weight: 700;
          color: #94a3b8; cursor: pointer; transition: 0.2s;
        }
        .tab-btn.active { background: #eff6ff; color: #2563eb; }
        .tab-btn:hover:not(.active) { background: #f8fafc; color: #64748b; }

        .info-row { font-size: 13px; color: #94a3b8; margin: 0 0 22px; }
        .info-row strong { color: #1e293b; }

        .story-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 22px; }

        .empty-state {
          text-align: center; padding: 60px 20px;
          display: flex; flex-direction: column; align-items: center; gap: 12px;
        }
        .empty-state > span { font-size: 48px; }
        .empty-state > p    { color: #94a3b8; font-size: 15px; margin: 0; }

        @media (max-width: 1100px) {
          .dp-grid    { grid-template-columns: 1fr; }
          .dp-sidebar { position: static; }
        }
        @media (max-width: 640px) {
          .story-grid { grid-template-columns: 1fr; }
          .main-card  { padding: 20px; }
          .tab-btn    { font-size: 12px; padding: 8px 12px; }
        }
      `}</style>
    </div>
  );
}
