import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma"; // ชี้ไปหาไฟล์ที่เราสร้างในสเต็ปที่ 1

export async function POST(request: Request) {
  try {
    // 1. รับข้อมูลที่ป้อนมาจากหน้าฟอร์มสมัครสมาชิก
    const body = await request.json();
    const { firstName, lastName, username, email, phone, password } = body;

    // 2. เช็คเบื้องต้นว่ากรอกข้อมูลครบตามที่ระบุในดาต้าเบสไหม
    if (!firstName || !lastName || !username || !email || !password) {
      return NextResponse.json(
        { message: "กรุณากรอกข้อมูลที่จำเป็นให้ครบถ้วน" },
        { status: 400 }
      );
    }

    // 3. เช็คความซ้ำซ้อนของข้อมูล (Email และ Username ห้ามซ้ำ)
    const existingEmail = await prisma.user.findUnique({
      where: { email },
    });
    if (existingEmail) {
      return NextResponse.json(
        { message: "อีเมลนี้ถูกใช้งานไปแล้ว" },
        { status: 400 }
      );
    }

    const existingUsername = await prisma.user.findUnique({
      where: { username },
    });
    if (existingUsername) {
      return NextResponse.json(
        { message: "ชื่อผู้ใช้งานนี้ถูกใช้งานไปแล้ว" },
        { status: 400 }
      );
    }

    // 4. สั่ง Prisma บันทึกข้อมูลลงฐานข้อมูล Supabase จริง
    const newUser = await prisma.user.create({
      data: {
        firstName,
        lastName,
        username,
        email,
        phone,
        password, // รหัสผ่าน (ในอนาคตเราจะมาต่อยอดลง bcrypt เพื่อเข้ารหัสกันครับ)
      },
    });

    // 5. ส่งสถานะตอบกลับหน้าบ้านเมื่อสำเร็จ
    return NextResponse.json(
      { message: "สมัครสมาชิกสำเร็จเรียบร้อยแล้ว!", userId: newUser.id },
      { status: 201 }
    );

  } catch (error) {
    console.error("Register Error:", error);
    return NextResponse.json(
      { message: "เกิดข้อผิดพลาดภายในระบบหลังบ้าน" },
      { status: 500 }
    );
  }
}
