"use client";

import { useState } from "react";
import {
  BackButton,
  CancelButton,
  SaveButton,
  ActionBar,
  PageTag,
} from "@/components/ui/ActionButtons";

import "@/components/ui/form-card.css";
import "@/components/ui/action-buttons.css";

export default function CreatePlacePage() {
  const [cover, setCover] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [location, setLocation] = useState("");
  const [description, setDescription] = useState("");

  const handleCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { alert("รูปปกต้องไม่เกิน 5MB"); return; }
    setCover(URL.createObjectURL(file));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert("บันทึกสถานที่เรียบร้อย / Place saved!");
  };

  return (
    <div className="cp-page">
      <div className="cp-container">

        {/* TOP BAR */}
        <div className="cp-topbar">
          <BackButton href="/business/dashboard" label="Dashboard" labelTh="กลับแดชบอร์ด" />
          <PageTag label="CREATE PLACE" />
        </div>

        {/* PAGE TITLE */}
        <div style={{ marginBottom: "28px" }}>
          <h1 style={{ fontSize: "32px", fontWeight: 900, color: "var(--pl-text-primary)", marginBottom: "6px" }}>
            เพิ่มสถานที่ใหม่
            <span style={{
              fontSize: "12px", fontWeight: 700,
              background: "var(--pl-blue-soft)", color: "var(--pl-blue-dark)",
              padding: "3px 10px", borderRadius: "6px", marginLeft: "12px", verticalAlign: "middle",
            }}>Create New Place</span>
          </h1>
          <p style={{ color: "var(--pl-text-secondary)", fontSize: "15px", margin: 0 }}>
            เพิ่มสถานที่ท่องเที่ยวใหม่เข้าสู่ระบบ · Add a new destination for travelers
          </p>
        </div>

        <form onSubmit={handleSubmit}>

          {/* COVER UPLOAD */}
          <div className="ui-section-card">
            <div className="ui-section-hdr">
              <div>
                <h2>รูปปกสถานที่ <span className="ui-en-tag">Cover Photo</span></h2>
                <p>ภาพที่จะแสดงในหน้าหลักของสถานที่ · Main image shown to travelers</p>
              </div>
            </div>

            <label className="cp-cover-upload">
              <input type="file" hidden accept="image/*" onChange={handleCoverUpload} />
              {cover ? (
                <img src={cover} alt="cover" className="cp-cover-img" />
              ) : (
                <div className="cp-cover-placeholder">
                  <span className="cp-cover-icon">🖼️</span>
                  <h3>คลิกเพื่ออัปโหลดรูปปก</h3>
                  <p>PNG, JPG ขนาดไม่เกิน 5MB · Click to upload cover image</p>
                </div>
              )}
              {cover && (
                <div className="cp-cover-overlay">
                  <span>เปลี่ยนรูปปก · Change cover</span>
                </div>
              )}
            </label>
          </div>

          {/* PLACE INFO */}
          <div className="ui-section-card">
            <div className="ui-section-hdr">
              <div>
                <h2>ข้อมูลสถานที่ <span className="ui-en-tag">Place Information</span></h2>
                <p>รายละเอียดที่นักท่องเที่ยวจะเห็น · Details visible to travelers</p>
              </div>
            </div>

            <div className="ui-form-grid">
              <div className="ui-field col-full">
                <label>ชื่อสถานที่ <span className="en">Place name</span></label>
                <input
                  className="ui-input"
                  type="text"
                  placeholder="เช่น น้ำตกเอราวัณ"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                />
              </div>

              <div className="ui-field col-full">
                <label>จังหวัด / ประเทศ <span className="en">Province / Country</span></label>
                <input
                  className="ui-input"
                  type="text"
                  placeholder="เช่น กาญจนบุรี, ประเทศไทย"
                  value={location}
                  onChange={e => setLocation(e.target.value)}
                />
              </div>

              <div className="ui-field col-full">
                <label>รายละเอียดสถานที่ <span className="en">Description</span></label>
                <textarea
                  className="ui-input textarea"
                  placeholder="อธิบายรายละเอียดสถานที่..."
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* ACTION FOOTER */}
          <ActionBar>
            <CancelButton href="/business/dashboard" label="ยกเลิก · Discard" />
            <SaveButton label="🚀 บันทึกสถานที่ · Save Place" />
          </ActionBar>

        </form>
      </div>

      <style jsx>{`
        .cp-page {
          min-height: 100vh;
          background: var(--pl-bg, #f8fafc);
          padding: 36px 20px 80px;
        }
        .cp-container {
          max-width: 1180px;
          margin: auto;
        }
        .cp-topbar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 28px;
          flex-wrap: wrap;
          gap: 12px;
        }

        /* Cover upload */
        .cp-cover-upload {
          display: block;
          width: 100%;
          height: 360px;
          border-radius: 24px;
          overflow: hidden;
          border: 2px dashed var(--pl-border, #dbeafe);
          background: #f8fbff;
          cursor: pointer;
          position: relative;
          transition: border-color 0.2s;
        }
        .cp-cover-upload:hover {
          border-color: var(--pl-blue, #4facfe);
        }
        .cp-cover-img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
        .cp-cover-placeholder {
          position: absolute;
          inset: 0;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          gap: 10px;
          color: #64748b;
        }
        .cp-cover-icon {
          font-size: 56px;
        }
        .cp-cover-placeholder h3 {
          font-size: 18px;
          font-weight: 800;
          color: #334155;
          margin: 0;
        }
        .cp-cover-placeholder p {
          font-size: 13px;
          color: #94a3b8;
          margin: 0;
        }
        .cp-cover-overlay {
          position: absolute;
          inset: 0;
          background: rgba(15,23,42,0.45);
          display: flex;
          align-items: center;
          justify-content: center;
          opacity: 0;
          transition: 0.2s;
        }
        .cp-cover-upload:hover .cp-cover-overlay {
          opacity: 1;
        }
        .cp-cover-overlay span {
          color: white;
          font-size: 15px;
          font-weight: 800;
          background: rgba(0,0,0,0.4);
          padding: 10px 22px;
          border-radius: 999px;
          backdrop-filter: blur(6px);
        }

        @media (max-width: 768px) {
          .cp-cover-upload { height: 220px; }
        }
      `}</style>
    </div>
  );
}
