"use client";

import { useState } from "react";
import Link from "next/link";
import { mockPlaces } from "@/data/mockPlaces";
import { PROVINCES, getDistricts } from "@/data/thailand";
import "./page.css";

type Props = { params: { slug: string } };

const CATEGORIES = [
  "ธรรมชาติ","คาเฟ่","ที่พัก","แคมปิ้ง","อาหาร",
  "วัด / ศาสนสถาน","ชายหาด","ตลาด / ช้อปปิ้ง",
  "กีฬา / ผจญภัย","พิพิธภัณฑ์ / ประวัติศาสตร์",
];

const CATEGORY_ICON: Record<string, string> = {
  "ธรรมชาติ": "🌿","คาเฟ่": "☕","ที่พัก": "🏨",
  "แคมปิ้ง": "⛺","อาหาร": "🍲","วัด / ศาสนสถาน": "🛕",
  "ชายหาด": "🏖️","ตลาด / ช้อปปิ้ง": "🛍️",
  "กีฬา / ผจญภัย": "🧗","พิพิธภัณฑ์ / ประวัติศาสตร์": "🏛️",
};

export default function EditPlacePage({ params }: Props) {
  const place = mockPlaces.find((p) => p.slug === params.slug);

  // ── Basic info ──
  const [title, setTitle]           = useState(place?.title ?? "");
  const [titleEn, setTitleEn]       = useState(place?.titleEn ?? "");
  const [province, setProvince]     = useState(place?.province ?? "");
  const [district, setDistrict]     = useState(place?.district ?? "");
  const [address, setAddress]       = useState(place?.address ?? "");
  const [googleMaps, setGoogleMaps] = useState(place?.googleMapsUrl ?? "");
  const [category, setCategory]     = useState(place?.category ?? "ธรรมชาติ");
  const [tagInput, setTagInput]     = useState("");
  const [tags, setTags]             = useState<string[]>(place?.tags ?? []);

  // ── Description ──
  const [description, setDescription]   = useState(place?.description ?? "");
  const [descShort, setDescShort]       = useState(place?.descriptionShort ?? "");

  // ── Operating info ──
  const [openHours, setOpenHours]   = useState(place?.openHours ?? "");
  const [closedDays, setClosedDays] = useState(place?.closedDays ?? "");
  const [entryFee, setEntryFee]     = useState(place?.entryFee ?? "");
  const [phone, setPhone]           = useState(place?.phone ?? "");
  const [website, setWebsite]       = useState(place?.website ?? "");
  const [lineId, setLineId]         = useState(place?.lineId ?? "");

  // ── Media ──
  const [coverImage, setCoverImage] = useState(place?.image ?? "");
  const [gallery, setGallery]       = useState<string[]>(place?.gallery ?? []);
  const MAX_PHOTOS = 20;

  const districts = getDistricts(province);

  const handleProvinceChange = (v: string) => {
    setProvince(v);
    setDistrict("");
  };

  const handleCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { alert("รูปปกต้องไม่เกิน 5MB"); return; }
    setCoverImage(URL.createObjectURL(file));
  };

  const handleGalleryUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const remaining = MAX_PHOTOS - gallery.length;
    const valid = files.slice(0, remaining).filter((f) => f.size <= 5 * 1024 * 1024);
    setGallery((prev) => [...prev, ...valid.map((f) => URL.createObjectURL(f))]);
  };

  const addTag = () => {
    const t = tagInput.trim();
    if (t && !tags.includes(t)) setTags((prev) => [...prev, t]);
    setTagInput("");
  };

  const removeTag = (t: string) => setTags((prev) => prev.filter((x) => x !== t));

  const usedPct    = Math.round((gallery.length / MAX_PHOTOS) * 100);
  const countState = gallery.length >= MAX_PHOTOS ? "full" : gallery.length >= 15 ? "warn" : "ok";

  return (
    <div className="edit-page">
      <div className="edit-container">

        {/* TOP BAR */}
        <div className="top-bar">
          <Link href="/business/dashboard" className="back-btn">
            <span className="back-dot">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path d="M10 3L5 8L10 13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </span>
            <span className="back-text">กลับหน้าแดชบอร์ด <span className="back-en">Dashboard</span></span>
          </Link>
          <span className="page-badge">Edit Place</span>
        </div>

        {/* HEADER */}
        <div className="page-header">
          <h1>แก้ไขสถานที่ <span className="en-tag">Edit Place</span></h1>
          <p className="subtitle">ปรับข้อมูล รูปภาพ และรายละเอียดของสถานที่ท่องเที่ยว <span className="subtitle-en">· Update place details</span></p>
        </div>

        <form>

          {/* ── 1. COVER ── */}
          <div className="section-card">
            <div className="section-hdr">
              <div>
                <h2>รูปปกหลัก <span className="en-tag sm">Cover Photo</span></h2>
                <p>ภาพที่จะแสดงในหน้าหลักและการค้นหา</p>
              </div>
            </div>
            <label className="cover-upload">
              <input type="file" hidden accept="image/*" onChange={handleCoverUpload} />
              {coverImage
                ? <img src={coverImage} alt="cover" />
                : <div className="cover-empty">🖼️<span>คลิกเพื่ออัปโหลดรูปปก</span><small>PNG, JPG ไม่เกิน 5MB</small></div>
              }
              <div className="cover-overlay"><span>เปลี่ยนรูปปก</span></div>
            </label>
          </div>

          {/* ── 2. BASIC INFO ── */}
          <div className="section-card">
            <div className="section-hdr">
              <div>
                <h2>ข้อมูลพื้นฐาน <span className="en-tag sm">Basic Info</span></h2>
                <p>ชื่อ ประเภท และที่ตั้งของสถานที่</p>
              </div>
            </div>

            <div className="form-grid two-col">
              <div className="field">
                <label>ชื่อสถานที่ (ภาษาไทย) <span className="req">*</span></label>
                <input className="form-control" type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="เช่น น้ำตกเอราวัณ" />
              </div>
              <div className="field">
                <label>ชื่อภาษาอังกฤษ <span className="hint">English name</span></label>
                <input className="form-control" type="text" value={titleEn} onChange={(e) => setTitleEn(e.target.value)} placeholder="e.g. Erawan Waterfall" />
              </div>
            </div>

            <div className="field mt16">
              <label>ประเภทสถานที่ <span className="req">*</span></label>
              <div className="cat-grid">
                {CATEGORIES.map((c) => (
                  <button
                    key={c} type="button"
                    className={`cat-btn ${category === c ? "cat-active" : ""}`}
                    onClick={() => setCategory(c)}
                  >
                    {CATEGORY_ICON[c]} {c}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* ── 3. LOCATION ── */}
          <div className="section-card">
            <div className="section-hdr">
              <div>
                <h2>ที่ตั้งสถานที่ <span className="en-tag sm">Location</span></h2>
                <p>ข้อมูลนี้ใช้สำหรับการค้นหาตามจังหวัดและอำเภอ</p>
              </div>
            </div>

            <div className="form-grid two-col">
              <div className="field">
                <label>จังหวัด <span className="req">*</span></label>
                <select
                  className="form-control"
                  value={province}
                  onChange={(e) => handleProvinceChange(e.target.value)}
                >
                  <option value="">— เลือกจังหวัด —</option>
                  {PROVINCES.map((p) => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
              <div className="field">
                <label>อำเภอ / เขต <span className="req">*</span></label>
                <select
                  className="form-control"
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  disabled={!province}
                >
                  <option value="">— เลือกอำเภอ —</option>
                  {districts.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
                {!province && <span className="field-hint">เลือกจังหวัดก่อน</span>}
              </div>
            </div>

            <div className="field mt16">
              <label>ที่อยู่เพิ่มเติม <span className="hint">รายละเอียดที่อยู่</span></label>
              <input className="form-control" type="text" value={address} onChange={(e) => setAddress(e.target.value)} placeholder="เช่น 123 ถ.เพชรเกษม ต.ท่ากระดาน" />
            </div>

            <div className="field mt16">
              <label>Google Maps URL</label>
              <input className="form-control" type="url" value={googleMaps} onChange={(e) => setGoogleMaps(e.target.value)} placeholder="https://maps.google.com/?q=..." />
              {googleMaps && (
                <a href={googleMaps} target="_blank" rel="noreferrer" className="map-preview-link">
                  🗺️ ดูบน Google Maps
                </a>
              )}
            </div>
          </div>

          {/* ── 4. DESCRIPTION ── */}
          <div className="section-card">
            <div className="section-hdr">
              <div>
                <h2>คำอธิบายสถานที่ <span className="en-tag sm">Description</span></h2>
                <p>อธิบายให้นักท่องเที่ยวเข้าใจและสนใจมาเที่ยว</p>
              </div>
            </div>

            <div className="field">
              <label>คำอธิบายสั้น <span className="hint">แสดงในการ์ดค้นหา ไม่เกิน 80 ตัวอักษร</span></label>
              <input
                className="form-control"
                type="text"
                value={descShort}
                onChange={(e) => setDescShort(e.target.value)}
                placeholder="เช่น น้ำตก 7 ชั้น น้ำสีมรกต ในอุทยานแห่งชาติ"
                maxLength={80}
              />
              <span className="char-count">{descShort.length}/80</span>
            </div>

            <div className="field mt16">
              <label>คำอธิบายเต็ม <span className="hint">แสดงในหน้ารายละเอียด</span></label>
              <textarea
                className="form-control textarea"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="อธิบายรายละเอียด บรรยากาศ จุดเด่น และเคล็ดลับการเที่ยวชม..."
                rows={5}
              />
            </div>

            {/* Tags */}
            <div className="field mt16">
              <label>แท็ก <span className="hint">ช่วยให้ค้นหาเจอง่ายขึ้น</span></label>
              <div className="tag-input-row">
                <input
                  className="form-control"
                  type="text"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addTag())}
                  placeholder="พิมพ์แท็กแล้วกด Enter หรือปุ่ม +"
                />
                <button type="button" className="tag-add-btn" onClick={addTag}>+ เพิ่ม</button>
              </div>
              {tags.length > 0 && (
                <div className="tags-wrap">
                  {tags.map((t) => (
                    <span key={t} className="tag-chip">
                      {t}
                      <button type="button" onClick={() => removeTag(t)}>✕</button>
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* ── 5. OPERATING INFO ── */}
          <div className="section-card">
            <div className="section-hdr">
              <div>
                <h2>ข้อมูลการเปิด-ปิด และติดต่อ <span className="en-tag sm">Contact & Hours</span></h2>
                <p>ข้อมูลสำคัญที่นักท่องเที่ยวต้องการก่อนเดินทาง</p>
              </div>
            </div>

            <div className="form-grid two-col">
              <div className="field">
                <label>เวลาเปิด–ปิด</label>
                <input className="form-control" type="text" value={openHours} onChange={(e) => setOpenHours(e.target.value)} placeholder="เช่น 08:00 – 17:00" />
              </div>
              <div className="field">
                <label>วันหยุด / วันปิดทำการ</label>
                <input className="form-control" type="text" value={closedDays} onChange={(e) => setClosedDays(e.target.value)} placeholder="เช่น ปิดวันจันทร์, เปิดทุกวัน" />
              </div>
              <div className="field">
                <label>ค่าเข้าชม</label>
                <input className="form-control" type="text" value={entryFee} onChange={(e) => setEntryFee(e.target.value)} placeholder="เช่น ฟรี หรือ 50 ฿/คน" />
              </div>
              <div className="field">
                <label>เบอร์โทรศัพท์</label>
                <input className="form-control" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="เช่น 034-574222" />
              </div>
              <div className="field">
                <label>เว็บไซต์</label>
                <input className="form-control" type="url" value={website} onChange={(e) => setWebsite(e.target.value)} placeholder="https://..." />
              </div>
              <div className="field">
                <label>Line ID</label>
                <input className="form-control" type="text" value={lineId} onChange={(e) => setLineId(e.target.value)} placeholder="@yourlineid" />
              </div>
            </div>
          </div>

          {/* ── 6. GALLERY ── */}
          <div className="section-card">
            <div className="section-hdr">
              <div>
                <h2>รูปภาพเพิ่มเติม <span className="en-tag sm">Gallery</span></h2>
                <p>เพิ่มรูปภาพได้สูงสุด {MAX_PHOTOS} รูป</p>
              </div>
            </div>

            <div className="gallery-toprow">
              <span className={`count-pill ${countState}`}>{gallery.length} / {MAX_PHOTOS}</span>
              <label className={`add-photo-btn ${gallery.length >= MAX_PHOTOS ? "disabled" : ""}`}>
                + เพิ่มรูป
                <input type="file" hidden multiple accept="image/*" onChange={handleGalleryUpload} disabled={gallery.length >= MAX_PHOTOS} />
              </label>
            </div>

            {gallery.length === 0
              ? <div className="gallery-empty">🖼️<p>ยังไม่มีรูปภาพ · คลิก "+ เพิ่มรูป" เพื่ออัปโหลด</p></div>
              : (
                <div className="gallery-grid">
                  {gallery.map((img, i) => (
                    <div className="g-item" key={i}>
                      <img src={img} alt="" />
                      <button type="button" className="g-del" onClick={() => setGallery((prev) => prev.filter((_, j) => j !== i))}>✕</button>
                    </div>
                  ))}
                </div>
              )}

            <div className="progress-wrap">
              <div className={`progress-fill ${countState}`} style={{ width: `${usedPct}%` }} />
            </div>
          </div>

          {/* ── ACTIONS ── */}
          <div className="action-row">
            <Link href="/business/dashboard" className="btn-cancel">✕ ยกเลิก</Link>
            <Link href={`/place/${params.slug}`} className="btn-preview" target="_blank">👁️ ดูตัวอย่าง</Link>
            <button type="submit" className="btn-save">✓ บันทึกข้อมูล</button>
          </div>

        </form>
      </div>
    </div>
  );
}
