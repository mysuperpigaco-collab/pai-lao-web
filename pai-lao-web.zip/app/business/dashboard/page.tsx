"use client";

import BusinessDashboardHeader from "@/components/business/BusinessDashboardHeader";
import BusinessProfileCard from "@/components/business/BusinessProfileCard";
import BusinessPlaceCard from "@/components/business/BusinessPlaceCard";

/* ─── Stat card — inline style ป้องกัน globals ─── */
function StatCard({ value, label, labelEn, color, bg }: {
  value: string; label: string; labelEn: string; color: string; bg: string;
}) {
  return (
    <div style={{
      borderRadius: "24px",
      padding: "26px 28px",
      background: bg,
      display: "flex",
      flexDirection: "column",
      gap: "6px",
    }}>
      <strong style={{ fontSize: "40px", fontWeight: 900, color, lineHeight: 1 }}>{value}</strong>
      <span style={{ fontSize: "14px", fontWeight: 700, color: "#0f172a" }}>{label}</span>
      <small style={{ fontSize: "11px", color: "#64748b" }}>{labelEn}</small>
    </div>
  );
}

export default function BusinessDashboardPage() {
  return (
    <div className="dashboard-page">

      {/* ── HERO ── */}
      <section className="dashboard-hero">
        <p className="dashboard-tag">BUSINESS DASHBOARD</p>
        <h1>จัดการสถานที่ของคุณ</h1>
        <span>จัดการข้อมูล โปรไฟล์ รีวิว และจุดเช็คอินทั้งหมดได้ในที่เดียว · Manage all your places in one place</span>
      </section>

      {/* ── PROFILE CARD (มีปุ่มแก้ไขโปรไฟล์ inline style แล้ว) ── */}
      <BusinessProfileCard />

      {/* ── STATS ── */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(3, 1fr)",
        gap: "20px",
        marginBottom: "32px",
      }}>
        <StatCard value="3"    label="สถานที่ทั้งหมด"    labelEn="Total Places"        color="#2563eb" bg="#eff6ff" />
        <StatCard value="4.8"  label="คะแนนเฉลี่ย"       labelEn="Average Rating"      color="#15803d" bg="#dcfce7" />
        <StatCard value="12.4k" label="ยอดเข้าชมเดือนนี้" labelEn="Views This Month"    color="#9333ea" bg="#faf5ff" />
      </div>

      {/* ── PLACES HEADER + GRID ── */}
      <BusinessDashboardHeader />

      <section className="manage-grid">
        <BusinessPlaceCard
          slug="erawan-waterfall"
          title="น้ำตกเอราวัณ"
          location="กาญจนบุรี, ประเทศไทย"
          image="https://images.unsplash.com/photo-1506744038136-46273834b3fb"
          category="🌊 ธรรมชาติ"
          rating="4.9"
          status="active"
          views={4820}
          checkins={1340}
        />
        <BusinessPlaceCard
          slug="mountain-cafe"
          title="คาเฟ่ริมเขา"
          location="เชียงใหม่, ประเทศไทย"
          image="https://images.unsplash.com/photo-1494526585095-c41746248156"
          category="☕ คาเฟ่"
          rating="4.7"
          status="active"
          views={5100}
          checkins={1210}
        />
        <BusinessPlaceCard
          slug="sea-view-camp"
          title="Sea View Camp"
          location="ระยอง, ประเทศไทย"
          image="https://images.unsplash.com/photo-1507525428034-b723cf961d3e"
          category="⛺ แคมปิ้ง"
          rating="4.8"
          status="pending"
          views={2480}
          checkins={650}
        />
      </section>

      <style jsx>{`
        .dashboard-page {
          width: 100%;
          max-width: 1440px;
          margin: 0 auto;
          padding: 40px 24px 80px;
        }

        /* Hero */
        .dashboard-hero {
          background: linear-gradient(135deg, #0f172a, #1e3a8a, #0f766e);
          border-radius: 36px;
          padding: 48px;
          color: white;
          margin-bottom: 24px;
          position: relative;
          overflow: hidden;
        }
        .dashboard-hero::before {
          content: "";
          position: absolute;
          width: 400px; height: 400px;
          background: rgba(255,255,255,0.06);
          border-radius: 999px;
          top: -120px; right: -120px;
        }
        .dashboard-tag {
          font-size: 11px;
          letter-spacing: 2.5px;
          font-weight: 800;
          color: rgba(255,255,255,0.6);
          margin: 0 0 12px;
        }
        .dashboard-hero h1 {
          font-size: 44px;
          font-weight: 900;
          margin: 0 0 12px;
          line-height: 1.1;
          color: #ffffff;
        }
        .dashboard-hero span {
          display: block;
          color: rgba(255,255,255,0.75);
          font-size: 15px;
          line-height: 1.7;
          max-width: 640px;
        }

        /* Places grid */
        .manage-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 24px;
        }

        @media (max-width: 768px) {
          .dashboard-page  { padding: 24px 16px 60px; }
          .dashboard-hero  { padding: 32px 24px; border-radius: 28px; }
          .dashboard-hero h1 { font-size: 32px; }
        }
      `}</style>
    </div>
  );
}
