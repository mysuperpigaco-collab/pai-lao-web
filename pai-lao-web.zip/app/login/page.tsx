"use client";

import { useState } from "react";
import { useRouter } from "next/navigation"; // นำเข้า useRouter สำหรับเปลี่ยนหน้า
import Link from "next/link";
import InputField from "@/components/ui/InputField";

export default function LoginPage() {
  const router = useRouter(); // สร้างตัวแปรจัดการเส้นทาง
  const [isLoading, setIsLoading] = useState(false); // สถานะการโหลดตอนกดปุ่ม

  const [formData, setFormData] = useState({
    identifier: "",
    password: "",
    rememberMe: false,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true); // เริ่มการโหลด

    console.log("Submit Data:", formData);

    // จำลองการตรวจสอบ (Mockup Login)
    setTimeout(() => {
      if (
        (formData.identifier === "admin" || formData.identifier === "admin@test.com") && 
        formData.password === "1234"
      ) {
        // ✅ ถ้าผ่าน: ส่งตัวไปหน้า Dashboard ของตัวเอง
        router.push("/dashboard");
      } else {
        alert("อีเมล/ชื่อผู้ใช้งาน หรือรหัสผ่านไม่ถูกต้อง");
        setIsLoading(false); // หยุดการโหลดเพื่อให้แก้ข้อมูล
      }
    }, 1000); // หน่วงเวลา 1 วินาทีให้ดูเหมือนระบบกำลังทำงาน
  };

  return (
    <div className="auth-container">
      <div className="auth-card">
        <h2 style={{ fontWeight: 800, marginBottom: "10px", fontSize: "28px" }}>
          เข้าสู่ระบบ | <span style={{ color: "#3b82f6" }}>Login</span>
        </h2>
        <p style={{ color: "#999", marginBottom: "35px", fontSize: "14px" }}>
          ยินดีต้อนรับกลับสู่สังคมนักเดินทาง | Welcome Back
        </p>

        <form onSubmit={handleSubmit}>
          <InputField
            label="ชื่อผู้ใช้งาน หรือ อีเมล"
            labelEn="Username or Email"
            name="identifier"
            value={formData.identifier}
            onChange={handleChange}
            placeholder="admin หรือ admin@test.com"
            required
          />

          <InputField
            label="รหัสผ่าน"
            labelEn="Password"
            name="password"
            type="password"
            value={formData.password}
            onChange={handleChange}
            placeholder="1234"
            required
          />

          <div className="form-options">
            <label className="remember-me">
              <input 
                type="checkbox" 
                name="rememberMe" 
                checked={formData.rememberMe} 
                onChange={handleChange} 
              />
              <span>จดจำฉัน | Remember me</span>
            </label>
            <Link href="/forgot-password" style={{ color: "#3b82f6", fontSize: "13px", textDecoration: "none", fontWeight: "600" }}>
              ลืมรหัสผ่าน? | Forgot?
            </Link>
          </div>

          <button 
            type="submit" 
            className="btn-login-submit" 
            disabled={isLoading}
          >
            {isLoading ? "กำลังตรวจสอบ..." : "เข้าสู่ระบบ | Sign In"}
          </button>

          <div className="divider"><span>หรือ | OR</span></div>
          
          <button type="button" className="btn-google" onClick={() => alert('กำลังเชื่อมต่อ Google...')}>
            <img src="https://gstatic.com" alt="G" />
            ล็อกอินด้วย Google
          </button>
        </form>

        <div className="auth-footer">
          <p>ยังไม่มีบัญชี? <Link href="/signup" className="link-signup">สมัครสมาชิก</Link></p>
        </div>
      </div>

      <style jsx>{`
        .auth-container { min-height: 85vh; display: flex; align-items: center; justify-content: center; padding: 40px 20px; background-color: #f8fafc; }
        .auth-card { background: white; padding: 50px; border-radius: 40px; box-shadow: 0 20px 60px rgba(0,0,0,0.05); width: 100%; max-width: 480px; text-align: center; }
        .form-options { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; padding: 0 5px; }
        .remember-me { display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 13px; color: #666; }
        .remember-me input { width: 16px; height: 16px; accent-color: #3b82f6; cursor: pointer; }
        
        .btn-login-submit { 
          width: 100%; 
          padding: 16px; 
          border-radius: 50px; 
          border: none; 
          background: linear-gradient(135deg, #3b82f6 0%, #10b981 100%); 
          color: white; 
          font-weight: 800; 
          font-size: 16px; 
          cursor: pointer; 
          transition: 0.3s;
          opacity: ${isLoading ? 0.7 : 1};
        }
        .btn-login-submit:hover { transform: translateY(-2px); box-shadow: 0 10px 20px rgba(59,130,246,0.2); }

        .divider { margin: 25px 0; border-bottom: 1px solid #eee; position: relative; }
        .divider span { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: #fff; padding: 0 15px; color: #ccc; font-size: 12px; }
        
        .btn-google { width: 100%; padding: 12px; border-radius: 50px; border: 1px solid #ddd; background: #fff; display: flex; align-items: center; justify-content: center; gap: 10px; cursor: pointer; font-weight: 600; font-size: 14px; transition: 0.3s; }
        .btn-google img { width: 18px; }
        .btn-google:hover { background: #f9f9f9; border-color: #ccc; }
        
        .auth-footer { margin-top: 30px; }
        .link-signup { color: #3b82f6; font-weight: 700; text-decoration: none; }
        .link-signup:hover { text-decoration: underline; }
      `}</style>
    </div>
  );
}
