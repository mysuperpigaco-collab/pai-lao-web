"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowRight, LayoutDashboard } from "lucide-react";

export default function CreateStoryPage() {
  const today = new Date().toISOString().split("T")[0];

  // --- State Management ---
  const [cover, setCover] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [budget, setBudget] = useState("");
  const [mood, setMood] = useState("Cafe Hopping");
  const [videoLinks, setVideoLinks] = useState([""]);
  const [gallery, setGallery] = useState<string[]>([]);
  const [showPreview, setShowPreview] = useState(false);
  const [isBackHover, setIsBackHover] = useState(false);
  const [timeline, setTimeline] = useState([
    { date: today, time: "", place: "", province: "", district: "", description: "", image: null as string | null }
  ]);

  const districtData: Record<string, string[]> = {
    "chiangmai": ["แม่ริม", "หางดง", "จอมทอง", "เมืองเชียงใหม่"],
    "bangkok": ["พระนคร", "ปทุมวัน", "บางรัก", "สุขุมวิท"],
  };

  // --- Functions ---
  const handleCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) setCover(URL.createObjectURL(file));
  };

  const handleGalleryUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const newImgs = files.map(file => URL.createObjectURL(file));
    setGallery([...gallery, ...newImgs]);
  };

  const updateTimeline = (index: number, field: string, value: any) => {
    const updated = [...timeline];
    (updated[index] as any)[field] = value;
    if (field === "province") updated[index].district = ""; 
    setTimeline(updated);
  };

  const handleCheckpointImage = (index: number, file: File | null) => {
    if (file) updateTimeline(index, "image", URL.createObjectURL(file));
  };

  const addTimeline = () => setTimeline([...timeline, { date: today, time: "", place: "", province: "", district: "", description: "", image: null }]);
  const removeTimeline = (index: number) => setTimeline(timeline.filter((_, i) => i !== index));

  return (
    <div className="create-container">
      <div className="create-card">
        
        <div className="top-nav-actions">
          <Link
            href="/dashboard"
            aria-label="กลับไปแดชบอร์ด"
            onMouseEnter={() => setIsBackHover(true)}
            onMouseLeave={() => setIsBackHover(false)}
            style={{
              width: "100%",
              maxWidth: 430,
              minHeight: 84,
              display: "flex",
              alignItems: "center",
              gap: 14,
              padding: "14px 16px",
              border: `1.5px solid ${isBackHover ? "#bfdbfe" : "#dbe7f3"}`,
              borderRadius: 22,
              color: "#0f172a",
              background: "linear-gradient(180deg, rgba(255,255,255,0.99), rgba(248,250,252,0.96))",
              boxShadow: isBackHover
                ? "0 18px 36px rgba(15,23,42,0.1)"
                : "0 12px 26px rgba(15,23,42,0.06)",
              textDecoration: "none",
              transform: isBackHover ? "translateY(-3px)" : "translateY(0)",
              transition: "transform 0.22s ease, box-shadow 0.22s ease, border-color 0.22s ease",
            }}
          >
            <span
              style={{
                width: 46,
                height: 46,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flex: "0 0 46px",
                borderRadius: 16,
                color: "#2563eb",
                background: "#eff6ff",
              }}
            >
              <LayoutDashboard size={20} />
            </span>

            <span
              style={{
                minWidth: 0,
                display: "flex",
                flex: "1 1 auto",
                flexDirection: "column",
                lineHeight: 1.15,
              }}
            >
              <strong
                style={{
                  color: "#0f172a",
                  fontSize: 14,
                  fontWeight: 900,
                  letterSpacing: 0,
                  textDecoration: "none",
                }}
              >
                กลับไปแดชบอร์ด
              </strong>
              <small
                style={{
                  marginTop: 5,
                  color: "#64748b",
                  fontSize: 11,
                  fontWeight: 700,
                  textDecoration: "none",
                }}
              >
                ดูโปรไฟล์และเรื่องเล่าของฉัน
              </small>
            </span>

            <span
              style={{
                width: 28,
                height: 28,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flex: "0 0 28px",
                borderRadius: 10,
                color: "#2563eb",
                background: "#eff6ff",
                opacity: isBackHover ? 1 : 0.35,
                transform: isBackHover ? "translateX(0)" : "translateX(-4px)",
                transition: "0.22s ease",
              }}
            >
              <ArrowRight size={16} />
            </span>
          </Link>
        </div>

        <div className="header-text">
          <h2>บอกเล่าประสบการณ์ใหม่ของคุณ</h2>
          <p>SHARE YOUR STORY | บันทึกการเดินทางในแบบของคุณ</p>
        </div>

        <form onSubmit={(e) => e.preventDefault()}>
          {/* 1. Cover Image */}
          <div className="cover-upload-area" onClick={() => document.getElementById('coverInput')?.click()}>
            {cover ? (
              <img src={cover} alt="Cover" className="cover-preview" />
            ) : (
              <div className="upload-placeholder">
                <span className="icon-main">🖼️</span>
                <h4>คลิกเพื่อเพิ่มรูปหน้าปกทริป</h4>
                <p>1200 x 630px สำหรับการแสดงผลที่ดีที่สุด</p>
              </div>
            )}
            <input type="file" id="coverInput" hidden accept="image/*" onChange={handleCoverUpload} />
          </div>

          {/* 2. ข้อมูลพื้นฐาน */}
          <div className="info-grid">
            <div className="form-group full-width">
              <label>หัวข้อเรื่องเล่า | <small>TITLE</small> <span>*</span></label>
              <input type="text" className="form-control" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="ตั้งชื่อทริปให้น่าสนใจ..." required />
            </div>
            <div className="form-group full-width">
              <label>เรื่องเล่าโดยรวม | <small>OVERALL</small> <span>*</span></label>
              <textarea className="form-control text-area" value={content} onChange={(e) => setContent(e.target.value)} placeholder="เล่าความประทับใจในภาพรวมของทริปนี้..." required />
            </div>
            <div className="form-group">
              <label>งบประมาณ | <small>BUDGET</small></label>
              <input type="number" className="form-control" value={budget} onChange={(e) => setBudget(e.target.value)} placeholder="บาท (THB)" />
            </div>
            <div className="form-group">
              <label>สไตล์ทริป | <small>MOOD</small></label>
              <select className="form-control" value={mood} onChange={(e) => setMood(e.target.value)}>
                <option>Cafe Hopping</option>
                <option>สายลุย Adventurous</option>
                <option>กินแหลก Foodie</option>
                <option>พักผ่อน Relaxing</option>
              </select>
            </div>
          </div>

          {/* 3. Timeline */}
          <div className="section-box">
            <h3 className="section-label">🕘 เส้นทางเดินทาง | <small>TIMELINE</small></h3>
            {timeline.map((item, idx) => (
              <div key={idx} className="timeline-card">
                <div className="timeline-top-row">
                  <input type="date" className="form-control" value={item.date} max={today} onChange={(e) => updateTimeline(idx, "date", e.target.value)} />
                  <input type="time" className="form-control" value={item.time} onChange={(e) => updateTimeline(idx, "time", e.target.value)} />
                  <input type="text" className="form-control flex-1" placeholder="ชื่อสถานที่ / จุดเช็คอิน" value={item.place} onChange={(e) => updateTimeline(idx, "place", e.target.value)} />
                  <button type="button" className="btn-remove-circle" onClick={() => removeTimeline(idx)}>×</button>
                </div>
                <div className="timeline-location-row">
                  <select className="form-control" value={item.province} onChange={(e) => updateTimeline(idx, "province", e.target.value)}>
                    <option value="">-- เลือกจังหวัด --</option>
                    <option value="chiangmai">เชียงใหม่</option>
                    <option value="bangkok">กรุงเทพฯ</option>
                  </select>
                  <select className="form-control" disabled={!item.province} value={item.district} onChange={(e) => updateTimeline(idx, "district", e.target.value)}>
                    <option value="">-- เลือกอำเภอ --</option>
                    {item.province && districtData[item.province].map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
                <div className="timeline-detail-row">
                  <textarea className="form-control desc-area" placeholder="เล่าบรรยากาศที่จุดนี้..." value={item.description} onChange={(e) => updateTimeline(idx, "description", e.target.value)} />
                  <div className="cp-upload-container">
                    {item.image ? (
                      <div className="cp-preview-box">
                        <img src={item.image} alt="checkpoint" />
                        <button onClick={() => updateTimeline(idx, "image", null)}>ลบรูป</button>
                      </div>
                    ) : (
                      <label className="cp-label">
                        <span>📷 เพิ่มรูป</span>
                        <input type="file" hidden accept="image/*" onChange={(e) => handleCheckpointImage(idx, e.target.files?.[0] || null)} />
                      </label>
                    )}
                  </div>
                </div>
              </div>
            ))}
            <button type="button" className="btn-add-checkpoint-premium" onClick={addTimeline}>
               <span className="plus">+</span> เพิ่มจุดเช็คอินใหม่ | Add Checkpoint
            </button>
          </div>

          {/* 4. Action Buttons ดีไซน์พรีเมียม */}
          <div className="main-actions">
            <button type="button" className="btn-action-preview" onClick={() => setShowPreview(true)}>
              👁️ ดูตัวอย่างทริป | Preview
            </button>
            <button type="submit" className="btn-action-publish">
              🚀 ลงเรื่องเล่าเลย! | Publish Now
            </button>
          </div>
        </form>
      </div>

      {/* --- Preview Modal --- */}
      {showPreview && (
        <div className="modal-overlay">
          <div className="modal-content">
            <button className="close-btn" onClick={() => setShowPreview(false)}>×</button>
            <div className="pv-header">
              {cover && <img src={cover} alt="Cover" />}
              <div className="pv-title-box">
                <span className="pv-tag">{mood}</span>
                <h1>{title || "หัวข้อเรื่องเล่า"}</h1>
                <p>โดย: คุณนักเล่าเรื่อง | งบประมาณ: {budget || 0} THB</p>
              </div>
            </div>
            <div className="pv-body">
              <p className="pv-main-content">{content}</p>
              <div className="pv-timeline">
                {timeline.map((t, i) => (
                  <div key={i} className="pv-item">
                    <div className="pv-dot"></div>
                    <div className="pv-time"><strong>{t.time || "--:--"}</strong></div>
                    <div className="pv-info">
                      <h4>{t.place || "จุดเช็คอิน"}</h4>
                      {t.description && <p className="pv-desc">{t.description}</p>}
                      {t.image && <img src={t.image} className="pv-checkpoint-img" alt="checkpoint" />}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        .create-container { padding: 50px 20px; background: #f0f4f8; min-height: 100vh; display: flex; justify-content: center; }
        .create-card { background: white; padding: 60px; border-radius: 50px; box-shadow: 0 30px 80px rgba(0,0,0,0.08); width: 100%; max-width: 1050px; position: relative; }

        .top-nav-actions { margin-bottom: 30px; }

        .header-text { text-align: center; margin-bottom: 50px; }
        .header-text h2 { font-size: 34px; font-weight: 900; color: #1e293b; letter-spacing: -0.5px; }
        .header-text p { color: #94a3b8; font-size: 14px; letter-spacing: 2px; text-transform: uppercase; font-weight: 600; margin-top: 10px; }

        /* Sections & Inputs */
        .cover-upload-area { width: 100%; height: 420px; border: 3px dashed #e2e8f0; border-radius: 40px; overflow: hidden; cursor: pointer; position: relative; background: #fafbfc; transition: 0.4s; }
        .cover-upload-area:hover { border-color: #3b82f6; background: #f0f7ff; transform: scale(1.005); }
        .upload-placeholder { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center; }
        .upload-placeholder .icon-main { font-size: 60px; margin-bottom: 20px; display: block; }
        .cover-preview { width: 100%; height: 100%; object-fit: cover; }

        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 25px; margin-top: 40px; }
        .full-width { grid-column: span 2; }
        .section-box { margin-top: 40px; padding: 35px; border-radius: 40px; background: #fff; border: 1px solid #f1f5f9; box-shadow: 0 10px 20px rgba(0,0,0,0.01); }
        .section-label { font-weight: 900; font-size: 20px; margin-bottom: 25px; color: #1e293b; border-left: 5px solid #3b82f6; padding-left: 15px; }

        .timeline-card { background: #fcfcfd; border: 1px solid #edf2f7; border-radius: 30px; padding: 30px; margin-bottom: 25px; box-shadow: 0 4px 10px rgba(0,0,0,0.02); }
        .timeline-top-row { display: flex; gap: 15px; margin-bottom: 15px; }
        .timeline-detail-row { display: grid; grid-template-columns: 1fr 180px; gap: 20px; margin-top: 15px; }
        .desc-area { height: 110px; border-radius: 20px; resize: none; background: white !important; }
        
        .cp-upload-container { height: 110px; }
        .cp-label { width: 100%; height: 100%; border: 2px dashed #cbd5e1; border-radius: 20px; display: flex; flex-direction: column; align-items: center; justify-content: center; cursor: pointer; color: #64748b; font-size: 12px; font-weight: 700; transition: 0.3s; background: white; }
        .cp-label:hover { border-color: #3b82f6; color: #3b82f6; background: #f0f7ff; }
        .cp-preview-box { position: relative; width: 100%; height: 100%; border-radius: 20px; overflow: hidden; }
        .cp-preview-box img { width: 100%; height: 100%; object-fit: cover; }
        .cp-preview-box button { position: absolute; bottom: 0; width: 100%; background: rgba(239, 68, 68, 0.85); color: white; border: none; font-size: 11px; font-weight: 700; padding: 6px; cursor: pointer; }

        .form-control { width: 100%; padding: 14px 20px; border-radius: 15px; border: 1px solid #e2e8f0; outline: none; background: #f8fafc; font-size: 15px; transition: 0.3s; }
        .form-control:focus { border-color: #3b82f6; background: white; box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1); }

        /* ✅ ปุ่มเพิ่มจุดเช็คอินแบบใหม่ */
        .btn-add-checkpoint-premium {
          width: 100%; padding: 20px; border-radius: 25px; border: 2px dashed #3b82f6; 
          color: #3b82f6; background: #f0f7ff; font-weight: 800; cursor: pointer; 
          transition: 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); display: flex; align-items: center; justify-content: center; gap: 10px;
        }
        .btn-add-checkpoint-premium:hover { background: #3b82f6; color: white; transform: scale(1.01); box-shadow: 0 15px 30px rgba(59,130,246,0.2); }
        .btn-add-checkpoint-premium .plus { font-size: 24px; }

        /* ✅ Action Buttons ด้านล่าง */
        .main-actions { display: flex; gap: 25px; margin-top: 60px; }
        .btn-action-preview { flex: 1; padding: 20px; border-radius: 25px; border: 2px solid #3b82f6; color: #3b82f6; font-weight: 800; cursor: pointer; background: white; transition: 0.3s; font-size: 16px; }
        .btn-action-preview:hover { background: #f0f7ff; box-shadow: 0 10px 20px rgba(59,130,246,0.1); }
        .btn-action-publish { flex: 2; padding: 20px; border-radius: 25px; border: none; background: linear-gradient(135deg, #3b82f6, #10b981); color: white; font-weight: 800; cursor: pointer; font-size: 18px; box-shadow: 0 20px 40px rgba(59,130,246,0.3); transition: 0.4s; }
        .btn-action-publish:hover { transform: translateY(-5px); box-shadow: 0 30px 60px rgba(59,130,246,0.4); filter: brightness(1.05); }

        /* Preview Modal (เหมือนเดิมที่สวยอยู่แล้ว) */
        .modal-overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(15, 23, 42, 0.9); backdrop-filter: blur(12px); z-index: 3000; display: flex; justify-content: center; padding: 50px 20px; overflow-y: auto; }
        .modal-content { background: white; width: 100%; max-width: 900px; border-radius: 50px; position: relative; height: fit-content; overflow: hidden; padding-bottom: 60px; box-shadow: 0 50px 100px rgba(0,0,0,0.5); }
        .close-btn { position: absolute; top: 30px; right: 30px; font-size: 30px; border: none; background: rgba(255,255,255,0.9); color: #1e293b; width: 50px; height: 50px; border-radius: 50%; cursor: pointer; z-index: 10; box-shadow: 0 10px 20px rgba(0,0,0,0.1); display: flex; align-items: center; justify-content: center; transition: 0.3s; }
        .close-btn:hover { background: #ef4444; color: white; transform: rotate(90deg); }
        .pv-header { width: 100%; height: 500px; position: relative; }
        .pv-header img { width: 100%; height: 100%; object-fit: cover; }
        .pv-title-box { position: absolute; bottom: 0; left: 0; right: 0; padding: 80px 50px 50px; background: linear-gradient(transparent, rgba(15, 23, 42, 0.95)); color: #fff; }
        .pv-tag { background: #3b82f6; padding: 6px 18px; border-radius: 50px; font-size: 13px; font-weight: 800; text-transform: uppercase; }
        .pv-title-box h1 { font-size: 42px; margin: 15px 0; font-weight: 900; line-height: 1.1; }
        .pv-body { padding: 50px; }
        .pv-main-content { line-height: 2; color: #475569; font-size: 18px; margin-bottom: 50px; white-space: pre-wrap; }
        .pv-timeline { border-left: 4px solid #3b82f6; padding-left: 40px; margin-left: 15px; }
        .pv-item { position: relative; margin-bottom: 50px; }
        .pv-dot { position: absolute; left: -49px; top: 8px; width: 18px; height: 18px; background: #3b82f6; border-radius: 50%; border: 4px solid #fff; box-shadow: 0 0 0 6px rgba(59, 130, 246, 0.2); }
        .pv-info h4 { margin: 0; font-size: 24px; color: #1e293b; font-weight: 800; }
        .pv-desc { color: #64748b; line-height: 1.8; margin: 15px 0; font-size: 16px; }
        .pv-checkpoint-img { width: 100%; max-width: 500px; border-radius: 30px; margin-top: 20px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); }

        @media (max-width: 768px) {
          .info-grid { grid-template-columns: 1fr; }
          .timeline-detail-row { grid-template-columns: 1fr; }
          .main-actions { flex-direction: column; }
          .create-card { padding: 30px; }
        }

      `}</style>
    </div>
  );
}
